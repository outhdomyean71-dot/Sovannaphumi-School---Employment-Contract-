/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  customLogoUrl?: string;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 120, customLogoUrl }) => {
  if (customLogoUrl) {
    return (
      <div className={`flex flex-col items-center justify-center text-center ${className}`}>
        <img
          src={customLogoUrl}
          alt="School Logo"
          style={{ width: `${size}px`, height: `${size}px` }}
          className="object-contain drop-shadow-md hover:scale-105 transition-transform duration-300"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  return (
    <div className={`flex flex-col items-center justify-center text-center ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-md hover:scale-105 transition-transform duration-300"
      >
        {/* Outer Ring */}
        <circle cx="100" cy="100" r="95" fill="#ffffff" stroke="#0056ac" strokeWidth="6" />
        <circle cx="100" cy="100" r="88" fill="#0056ac" />
        
        {/* Yellow Inner Ring */}
        <circle cx="100" cy="100" r="72" fill="#fed600" />
        
        {/* White Inner Badge Frame */}
        <circle cx="100" cy="100" r="54" fill="#ffffff" stroke="#c41c17" strokeWidth="2" />
        
        {/* Red Shield outline / Flame base */}
        <path
          d="M100 56 C78 56, 74 88, 74 105 C74 128, 90 144, 100 144 C110 144, 126 128, 126 105 C126 88, 122 56, 100 56 Z"
          fill="#c41c17"
        />

        {/* Golden Torch Flame */}
        <path
          d="M100 68 C110 68, 114 82, 100 96 C86 82, 90 68, 100 68 Z"
          fill="#fed600"
        />
        
        {/* Central Yellow Emblem / Open Book & Shield */}
        <path
          d="M86 112 C92 110, 96 112, 100 115 C104 112, 108 110, 114 112 L114 130 C108 128, 104 130, 100 133 C96 130, 92 128, 86 130 Z"
          fill="#fed600"
          stroke="#411b0e"
          strokeWidth="1.5"
        />
        
        {/* Open Book Pages Line Details */}
        <path d="M100 115 L100 133" stroke="#411b0e" strokeWidth="1.5" />
        <path d="M90 118 L96 117" stroke="#411b0e" strokeWidth="1" />
        <path d="M90 122 L96 121" stroke="#411b0e" strokeWidth="1" />
        <path d="M90 126 L96 125" stroke="#411b0e" strokeWidth="1" />
        
        <path d="M110 118 L104 117" stroke="#411b0e" strokeWidth="1" />
        <path d="M110 122 L104 121" stroke="#411b0e" strokeWidth="1" />
        <path d="M110 126 L104 125" stroke="#411b0e" strokeWidth="1" />

        {/* Small Flame/Star Sparkle */}
        <polygon points="100,62 102,67 107,67 103,70 105,75 100,72 95,75 97,70 93,67 98,67" fill="#ffffff" />

        {/* Khmer text along top curved path */}
        <path id="khmerPath" d="M 23 100 A 77 77 0 0 1 177 100" fill="none" />
        <text className="font-moul text-[15px] tracking-[0.1em]" fill="#ffffff">
          <textPath href="#khmerPath" startOffset="50%" textAnchor="middle">
            សាលារៀនសុវណ្ណភូមិ
          </textPath>
        </text>

        {/* English text along bottom curved path */}
        <path id="englishPath" d="M 177 100 A 77 77 0 0 1 23 100" fill="none" />
        <text fill="#ffffff" className="font-sans font-bold text-[12px] tracking-[0.09em]">
          <textPath href="#englishPath" startOffset="50%" textAnchor="middle">
            SOVANNAPHUMI SCHOOL
          </textPath>
        </text>
      </svg>
    </div>
  );
};
