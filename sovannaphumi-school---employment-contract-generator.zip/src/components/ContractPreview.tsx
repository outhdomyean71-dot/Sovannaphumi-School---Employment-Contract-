import React, { useRef, useState } from 'react';
import { ContractData } from '../types';
import { Logo } from './Logo';
import { Printer, ZoomIn, ZoomOut, Eye, Download, Loader2 } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

interface ContractPreviewProps {
  data: ContractData;
  highlightBlanks: boolean;
  scale: number;
  setScale: (val: number) => void;
}

export const ContractPreview: React.FC<ContractPreviewProps> = ({
  data,
  highlightBlanks,
  scale,
  setScale,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isExporting, setIsExporting] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleExportPDF = async () => {
    if (isExporting) return;
    setIsExporting(true);

    const prevScale = scale;
    try {
      // 1. Temporarily set scale to 1 to ensure standard element dimensions for high-fidelity capture
      setScale(1.0);
      
      // Allow the DOM to render the scale update so coordinates are absolute A4 sizes
      await new Promise((resolve) => setTimeout(resolve, 250));

      const pages = containerRef.current?.querySelectorAll('.document-page');
      if (!pages || pages.length === 0) {
        throw new Error('No pages found for export');
      }

      // Initialize portrait A4 JS PDF instance
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true,
      });

      const pdfWidth = 210; // A4 standard width in mm
      const pdfHeight = 297; // A4 standard height in mm

      for (let i = 0; i < pages.length; i++) {
        const pageElement = pages[i] as HTMLElement;
        
        // Capture each page individually with 2.5x scaling for razor-sharp text and glyphs
        const canvas = await html2canvas(pageElement, {
          scale: 2.5,
          useCORS: true,
          backgroundColor: '#ffffff',
          logging: false,
          scrollX: 0,
          scrollY: 0,
          windowWidth: 794,  // A4 width in pixels at standard 96 DPI
          windowHeight: 1123, // A4 height in pixels at standard 96 DPI
        });

        const imgData = canvas.toDataURL('image/jpeg', 0.95);

        if (i > 0) {
          pdf.addPage();
        }

        // Draw image over full A4 page space with high compression
        pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight, undefined, 'FAST');
      }

      // Build file name gracefully
      const employeeName = data.employeeEn ? data.employeeEn.trim().replace(/\s+/g, '_') : 'Employee';
      const campusName = data.campusEn ? data.campusEn.trim().replace(/\s+/g, '_') : 'Sovannaphumi';
      const filename = `Employment_Contract_${employeeName}_${campusName}.pdf`;

      pdf.save(filename);
    } catch (error) {
      console.error('Failed to export PDF:', error);
      alert('Error exporting PDF. Please try again.');
    } finally {
      // Restore user's scale zoom setting
      setScale(prevScale);
      setIsExporting(false);
    }
  };

  const val = (khValue: string, defaultValue: string = '.....................................') => {
    const displays = khValue && khValue.trim() !== '' ? khValue : defaultValue;
    const isPlaceholder = !khValue || khValue.trim() === '';
    
    return (
      <span 
        className={`${
          isPlaceholder 
            ? 'text-red-500 font-semibold' 
            : highlightBlanks 
              ? 'bg-amber-100 text-slate-900 px-1 rounded border-b border-amber-300 font-bold' 
              : 'text-slate-900 border-b border-dashed border-slate-600 px-1 font-semibold'
        } transition-all duration-200`}
      >
        {displays}
      </span>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-150 border-l border-slate-250 no-print relative">
      {/* Loading overlay when generating the PDF */}
      {isExporting && (
        <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-[2px] flex items-center justify-center z-50 transition-all duration-200">
          <div className="bg-white p-6 rounded-2xl shadow-xl flex flex-col items-center max-w-xs text-center mx-4 border border-slate-100 animate-in fade-in zoom-in duration-200">
            <Loader2 className="w-10 h-10 text-[#0056ac] animate-spin mb-4" />
            <span className="font-moul text-[#c41c17] text-xs mb-1">
              កំពុងរៀបចំឯកសារ PDF...
            </span>
            <p className="font-sans font-bold text-slate-800 text-sm mb-1.5">
              Generating High-Res PDF
            </p>
            <p className="font-sans text-[11px] text-slate-500 leading-normal">
              Please wait while we render each page in premium print-quality...
            </p>
          </div>
        </div>
      )}

      {/* Zoom and Print Control Header */}
      <div className="p-4 bg-white border-b border-slate-200 flex flex-wrap gap-3 items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-blue-600 animate-pulse" />
          <span className="text-sm font-bold text-slate-800">សន្លឹកកិច្ចសន្យាការងារពិតប្រាកដ / Live Document (4 Pages)</span>
        </div>
        
        <div className="flex items-center gap-2">
          {/* Zoom Controls */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200 hover:border-slate-300 transition duration-150">
            <button
              onClick={() => setScale(Math.max(0.5, scale - 0.1))}
              className="p-1 hover:bg-white rounded text-slate-600 hover:text-slate-900 transition"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-2xs font-bold px-1.5 text-slate-600 w-[38px] text-center">{Math.round(scale * 100)}%</span>
            <button
              onClick={() => setScale(Math.min(1.2, scale + 0.1))}
              className="p-1 hover:bg-white rounded text-slate-600 hover:text-slate-900 transition"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={handleExportPDF}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 bg-blue-700 hover:bg-blue-800 disabled:bg-blue-300 text-white rounded-lg text-xs font-bold shadow-sm transition-all duration-150 cursor-pointer hover:shadow"
          >
            <Download className="w-4 h-4" />
            ទាញយកជា PDF / Download PDF
          </button>

          <button
            onClick={handlePrint}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 text-white rounded-lg text-xs font-bold shadow-sm transition-all duration-150 cursor-pointer hover:shadow"
          >
            <Printer className="w-4 h-4" />
            បោះពុម្ពកិច្ចសន្យា / Print
          </button>
        </div>
      </div>

      {/* Pages Workspace Container */}
      <div className="flex-1 overflow-y-auto p-6 bg-slate-500/10 focus:outline-none">
        <div 
          ref={containerRef}
          style={{ transform: `scale(${scale})`, transformOrigin: 'top center' }}
          className="print-container space-y-8 pb-32 transition-transform duration-200 origin-top"
        >
          
          {/* PAGE 1 */}
          <div className="document-page text-justify" id="contract-page-1">
            {/* Header Logos and Name */}
            <div className="flex flex-col items-center mb-6">
              <Logo size={100} className="mb-2" customLogoUrl={data.customLogoUrl} />
              <h1 className="font-moul text-[#0056ac] text-[18px] tracking-[0.02em] mt-1 mb-0.5" style={{ textShadow: '0.5px 0.5px 0px rgba(0,0,0,0.1)' }}>
                សាលារៀនសុវណ្ណភូមិ
              </h1>
              <h2 className="font-sans font-bold text-[#0056ac] text-[16px] tracking-[0.06em] mb-4">
                SOVANNAPHUMI SCHOOL
              </h2>
              
              <div className="w-1/2 border-b-2 border-red-600 mb-4"></div>
              
              <h3 className="font-moul text-[#c41c17] text-[16px] mb-0.5">
                កិច្ចសន្យាការងារ
              </h3>
              <h4 className="font-sans font-bold text-[#0056ac] text-[13px] tracking-[0.1em] mb-1">
                EMPLOYMENT CONTRACT
              </h4>
              <p className="font-moul text-[#0056ac] text-[11px] mb-4">
                (ផ្នែកគ្រូបង្រៀន <span className="font-sans font-bold text-[11px]">Teaching Staff</span>)
              </p>
            </div>

            {/* Contract Body Part 1 */}
            <div className="space-y-4 text-xs leading-relaxed text-slate-800">
              <p className="indent-8 font-sans">
                <span className="font-bold">សាលារៀនសុវណ្ណភូមិ</span> នៃ ក្រុមហ៊ុន សហគមន៍ ញូវតុន ធីឡាយ គ្រុប ទីតាំង {val(data.campusKh, '_______________________')} តំណាងពេញច្បាប់ដោយ {val(data.representativeKh, '______________________')} មានតួនាទីជា {val(data.representativeRoleKh, '___________________')} ក្នុងកិច្ចសន្យានេះហៅថាភាគី <span className="font-bold">«និយោជក»</span> ជាមួយ និង {val(data.employeeKh, '______________________________')} កាន់អត្តសញ្ញាណប័ណ្ណលេខ៖ {val(data.employeeId, '____________________')} ទូរស័ព្ទដៃលេខ៖ {val(data.employeePhone, '________________________')} អាសយដ្ឋាន៖ ផ្ទះលេខ {val(data.houseNo, '_____')} ផ្លូវ {val(data.street, '________')} ភូមិ {val(data.village, '_______________')} ឃុំ/សង្កាត់ {val(data.sangkatKh, '__________________')} ស្រុក/ខណ្ឌ {val(data.khanKh, '_________________')} ខេត្ត/ក្រុង {val(data.cityKh, '_____________________')} ប្រទេស {val(data.countryKh, '__________')} ក្នុងកិច្ចសន្យានេះហៅថាភាគី <span className="font-bold">«និយោជិត»</span>។
              </p>

              <p className="font-sans font-medium text-slate-700 italic">
                <span className="font-bold not-italic font-sans text-slate-900">Sovannaphumi School</span> of SAHAKUM NEWTON THILAY GROUP CO., LTD, located at the {val(data.campusEn, '_________________________')} Campus, legally represented by {val(data.representativeEn, '_______________________')} as the {val(data.representativeRoleEn, '__________________')}; hereafter called <span className="font-bold not-italic">“The Employer”</span>
              </p>

              <p className="font-sans font-medium text-slate-700 italic">
                <span className="font-bold not-italic font-sans text-slate-900">And</span> {val(data.employeeEn, '______________________')}, holding ID card/Passport number: {val(data.employeeId, '_______________________')}, Phone#: {val(data.employeePhone, '_____________________')}, Address: {val(data.houseNo, '_____')}, St. {val(data.street, '_____')}, {val(data.village, '_____')}, Sangkat {val(data.sangkatEn, '_____')}, Khan {val(data.khanEn, '_____')}, {val(data.cityEn, '_____')}, {val(data.countryEn, '_____')}; hereafter called <span className="font-bold not-italic">“The Employee”</span>.
              </p>

              <div className="pt-2 border-t border-slate-100">
                <p className="font-sans font-bold text-slate-950 mb-2">
                  ភាគីទាំងពីរបានប្រកាសយល់ព្រមលើចំណុចដូចខាងក្រោម៖ <span className="font-bold text-slate-800 font-sans text-[11px] block md:inline">The parties hereby declare as follows:</span>
                </p>
                
                <div className="space-y-3 pl-4">
                  <div>
                    <span className="font-bold">ក. </span>
                    <span className="font-bold">សាលារៀនសុវណ្ណភូមិ</span> ភ្ជាប់សេវាកម្មសម្រាប់តួនាទីជា {val(data.positionKh, '______________________________')} ដោយផ្អែកលើលក្ខណៈសម្បត្តិសមត្ថភាព ចំណេះដឹង និងជំនាញ។
                    <p className="font-sans italic text-slate-600 pl-4 mt-1">
                      <span className="font-bold not-italic">Sovannaphumi School</span> desires to engage with the services of a {val(data.positionEn, '____________________')}, with the right qualifications, education, and expertise for the position.
                    </p>
                  </div>

                  <div>
                    <span className="font-bold">ខ. </span>
                    <span className="font-bold">និយោជិត</span> ត្រូវបានលក្ខណៈសម្បត្តិសមត្ថភាព ចំណេះដឹង និងជំនាញ ដែលត្រូវតាមតួនាទីនេះ ហើយបានយល់ព្រមចូលរួមការងារជាមួយសាលារៀនសុវណ្ណភូមិ។
                    <p className="font-sans italic text-slate-600 pl-4 mt-1">
                      The Employee confirms that they possess the qualifications, education, and expertise required for the position and agrees to fulfill the employee role with <span className="font-bold not-italic">Sovannaphumi School</span>.
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-150">
                <p className="font-bold">យោងតាមការរៀបរាប់ផ្នែកខាងលើ ភាគីទាំងពីរបានព្រមព្រៀងគ្នាលើលក្ខខណ្ឌការងារដូចខាងក្រោម៖</p>
                <p className="font-sans italic text-slate-600 mt-1">
                  Considering the abovementioned premises, the Parties agree to state the terms and conditions of the work, as follows:
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="absolute bottom-6 left-15 right-15 flex justify-between text-[10px] text-slate-450 border-t border-slate-100 pt-2">
              <span>Employment Contract - Teach Staff</span>
              <span>Page 1 of 4</span>
            </div>
          </div>


          {/* PAGE 2 */}
          <div className="document-page text-justify" id="contract-page-2">
            <div className="space-y-4 text-xs leading-relaxed text-slate-800">
              
              <div>
                <p className="font-bold">
                  ១. កិច្ចសន្យានេះ ជាប្រភេទកិច្ចសន្យាការងារដែលមានកំណត់ថិរវេលា។
                </p>
                <p className="font-sans italic text-slate-600 pl-5">
                  This Employment contract is Fixed Duration Contract (FDC).
                </p>
              </div>

              <div>
                <p className="font-bold mt-2">
                  ២. និយោជិតត្រូវបានផ្តល់ការងារដោយសាលារៀនសុវណ្ណភូមិ មានប្រសិទ្ធភាពចាប់ពីថ្ងៃទី {val(data.startDateDay, '____')} ខែ {val(data.startDateMonthKh, '______')} ឆ្នាំ {val(data.startDateYear, '____')} ដល់ថ្ងៃទី {val(data.endDateDay, '____')} ខែ {val(data.endDateMonthKh, '______')} ឆ្នាំ {val(data.endDateYear, '____')} និងត្រូវធ្វើរបាយការណ៍ផ្ទាល់ជូន {val(data.reportsToKh, '__________________')}។
                </p>
                <p className="font-sans italic text-slate-600 pl-5">
                  The Employee is employed by <span className="font-bold not-italic">Sovannaphumi School</span>, in the period from {val(data.startDateEn, '_______________')} to {val(data.endDateEn, '_______________')}, and reports directly to the {val(data.reportsToEn, '____________________')}.
                </p>
              </div>

              <div>
                <p className="font-bold mt-2">
                  ៣. ម៉ោងពេលបំពេញការងាររបស់និយោជិត <span className="font-sans font-bold">Employee Working Hours៖</span>
                </p>
                
                <div className="space-y-2 mt-2 pl-4">
                  <div className="flex items-start gap-2">
                    <input 
                      type="checkbox" 
                      checked={data.workingHoursType === 'fullTime'} 
                      readOnly 
                      className="mt-0.5 rounded text-blue-600" 
                    />
                    <div>
                      <span className="font-semibold">៣.១ ពេញម៉ោង៖</span> ព្រឹកចាប់ពីម៉ោង {val(data.ftMorningStart, '________')} ដល់ម៉ោង {val(data.ftMorningEnd, '________')} និងរសៀល ពីម៉ោង {val(data.ftAfternoonStart, '________')} ដល់ម៉ោង {val(data.ftAfternoonEnd, '________')} ហើយធ្វើការពីថ្ងៃ {val(data.workDaysKh, '___________')}។
                      <p className="font-sans italic text-slate-600 mt-0.5">
                        <span className="font-semibold not-italic">Full-Time:</span> The working hours are from {val(data.ftMorningStart, '_________')} to {val(data.ftMorningEnd, '_________')}; and {val(data.ftAfternoonStart, '_________')} to {val(data.ftAfternoonEnd, '_________')}, with work scheduled from {val(data.workDaysEn, 'Monday to Friday')}.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input 
                      type="checkbox" 
                      checked={data.workingHoursType === 'subjectTeacher'} 
                      readOnly 
                      className="rounded text-blue-600" 
                    />
                    <div>
                      <span className="font-semibold">៣.២ តាមមុខវិជ្ជា៖</span> ផ្អែកលើកាលវិភាគបង្រៀនប្រចាំខែ។
                      <p className="font-sans italic text-slate-600">
                        <span className="font-semibold not-italic">Subject Teacher:</span> Based on the monthly teaching schedule.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input 
                      type="checkbox" 
                      checked={data.workingHoursType === 'partTime'} 
                      readOnly 
                      className="rounded text-blue-600" 
                    />
                    <div>
                      <span className="font-semibold">៣.៣ ក្រៅម៉ោង៖</span> ផ្អែកលើកាលវិភាគបង្រៀនប្រចាំខែ។
                      <p className="font-sans italic text-slate-600">
                        <span className="font-semibold not-italic">Part-Time:</span> Based on the monthly teaching schedule.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <p className="font-bold mt-2">
                  ៤. ភារកិច្ច និងការទទួលខុសត្រូវ៖ <span className="font-normal font-sans">និយោជិតទទួលខុសត្រូវក្នុងការពង្រីក និងការផ្តល់នូវបរិយាកាសអប់រំល្អ ដែលអាចធ្វើឱ្យសិស្សានុសិស្សមានឱកាសបំពេញនូវភាពរីកចម្រើនផ្នែកប្រាជ្ញា ស្មារតី រាងកាយ អារម្មណ៍ និងផ្លូវចិត្ត។ និយោជិតក៏មានភារកិច្ចក្នុងការរៀបចំ និងអនុវត្តនូវវិធីសាស្ត្របង្រៀន ដែលអាចធ្វើឱ្យសិស្សសម្រេចបាននូវភាពជោគជ័យក្នុងការសិក្សា ស្របទៅតាមកម្មវិធីសិក្សារបស់សាលារៀនសុវណ្ណភូមិ។</span>
                </p>
                <p className="font-sans italic text-slate-600 mt-1 pl-2">
                  <span className="font-bold not-italic">The Duties and Responsibilities:</span> Employees are responsible for fostering a positive educational environment that supports students' intellectual, emotional, physical, and psychological growth. They are also tasked with designing and implementing effective teaching methods that help students achieve academic success in alignment with the curriculum of Sovannaphumi School.
                </p>
              </div>

              <div className="space-y-3 pl-4 pt-1">
                <div>
                  <span className="font-bold">៤.១ </span> អនុវត្តនូវសកម្មភាពបង្រៀនទាំងឡាយ ដែលអាចជួយឱ្យសិស្សមានបរិយាកាសល្អ ក្នុងការចូលរួមយ៉ាងសកម្មជាមួយបទពិសោធន៍សិក្សាដែលមានតម្លៃ និងអត្ថប្រយោជន៍។
                  <p className="font-sans italic text-slate-600 mt-0.5">
                    Implement teaching activities that foster a positive environment, encourage active student participation, and offer a meaningful learning experience.
                  </p>
                </div>

                <div>
                  <span className="font-bold">៤.២ </span> កំណត់ជ្រើសរើស និងកែសម្រួលដកស្រង់ឯកសារបង្រៀនផ្សេងៗឱ្យត្រូវតាមតម្រូវការរបស់សិស្ស ដោយផ្អែកលើប្រវត្តិរូប រចនាប័ទ្មសិក្សា និងសេចក្តីត្រូវការចាំបាច់ពិសេសរបស់សិស្ស។
                  <p className="font-sans italic text-slate-600 mt-0.5">
                    Identifies, selects, and modifies instructional resources to meet the needs of students with varying backgrounds, learning styles, and special needs.
                  </p>
                </div>

                <div>
                  <span className="font-bold">៤.៣ </span> ជួយក្នុងការវាយតម្លៃការផ្លាស់ប្តូរកម្មវិធីសិក្សា និងការចូលរួមចំណែកក្នុងផែនការអភិវឌ្ឍន៍សាលារៀន។
                  <p className="font-sans italic text-slate-600 mt-0.5">
                    Assist in evaluating curriculum modifications and contribute to the school development planning process.
                  </p>
                </div>

                <div>
                  <span className="font-bold">៤.៤ </span> ធានាឲ្យមានប្រសិទ្ធភាព និងសន្សំសំចៃខ្ពស់ចំពោះការរៀបចំ និងការប្រើប្រាស់ឯកសារផ្សេងៗ។
                  <p className="font-sans italic text-slate-600 mt-0.5">
                    Ensure the efficient and cost-effective preparation and use of documents.
                  </p>
                </div>

                <div>
                  <span className="font-bold">៤.៥ </span> ជួយបង្កើតបរិយាកាសល្អ ដែលអាចជួយឱ្យសិស្សានុសិស្សមានការជម្រុញ និងលើកទឹកចិត្តយ៉ាងសកម្មក្នុងដំណើរការនៃការសិក្សា។
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="absolute bottom-6 left-15 right-15 flex justify-between text-[10px] text-slate-450 border-t border-slate-100 pt-2">
              <span>Employment Contract - Teach Staff</span>
              <span>Page 2 of 4</span>
            </div>
          </div>


          {/* PAGE 3 */}
          <div className="document-page text-justify" id="contract-page-3">
            <div className="space-y-4 text-xs leading-relaxed text-slate-800">
              
              <div className="pl-4">
                <p className="font-sans italic text-slate-600">
                  Create a positive environment that actively motivates students throughout the learning process.
                </p>

                <div className="space-y-3 mt-3">
                  <div>
                    <span className="font-bold">៤.៦ </span> ធ្វើការទំនាក់ទំនងដោយមានភាពជាគំរូ និងមានប្រសិទ្ធភាព ទាំងការនិយាយ និងសរសេរជាមួយសិស្ស មាតាបិតាសិស្ស សហគមន៍ និងអ្នកពាក់ព័ន្ធផ្សេងទៀតឱ្យបានជាប្រចាំ ព្រមទាំងសហការជាមួយបុគ្គលិកការងាររួមដើម្បីធ្វើឱ្យបរិយាកាសនៃការបង្រៀនកាន់តែប្រសើរឡើង។
                    <p className="font-sans italic text-slate-600 mt-0.5">
                      Communicate exemplarily and effectively, both orally and in writing, with students, parents, community members, and other stakeholders on a regular basis, while also collaborating with colleagues to enhance the teaching environment.
                    </p>
                  </div>

                  <div>
                    <span className="font-bold">៤.៧ </span> ពិនិត្យមើលឱ្យច្បាស់ថា ភាពរីកចម្រើនរបស់សិស្ស និងលទ្ធភាពដែលសិស្សសម្រេចបាន នៅតែបន្តហើយមានលក្ខណៈត្រឹមត្រូវទៅតាមអាយុរបស់សិស្ស មុខវិជ្ជាសិក្សា និងតម្រូវការកម្មវិធីសិក្សា។
                    <p className="font-sans italic text-slate-600 mt-0.5">
                      Ensure that student progress and achievement are consistent with the student's age, subject area, and curriculum requirements.
                    </p>
                  </div>

                  <div>
                    <span className="font-bold">៤.៨ </span> ប្រតិបត្តិរាល់តួនាទី និងការទទួលខុសត្រូវបន្ថែមផ្សេងៗទៀត ទៅតាមការចាត់តាំងរបស់នាយក/នាយិកា នាយករង/នាយិការងស្របតាមសាលា។
                    <p className="font-sans italic text-slate-600 mt-0.5">
                      Perform any additional roles and responsibilities as assigned by the School Principal, Vice Principal, or School Coordinator.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <p className="font-bold mt-2">
                  ៥. និយោជិតនឹងទទួលបានប្រាក់រៀវត្ស និងអត្ថប្រយោជន៍ផ្សេងទៀតដូចខាងក្រោម (មុនកាត់ពន្ធ)៖
                </p>
                <p className="font-sans italic text-slate-600 pl-4">
                  The employee is entitled to the following salary and benefits (before tax):
                </p>

                <div className="space-y-2 mt-2 pl-4">
                  <div>
                    <span className="font-semibold">៥.១</span> ប្រាក់រៀវត្សគោលប្រចាំខែគឺ {data.paymentType === 'monthly' ? val(data.monthlySalaryAmount + ' USD', '_____________ USD') : val('_________________')} ឬ អត្រាម៉ោងគឺ {data.paymentType === 'hourly' ? val(data.hourlyRateAmount + ' USD / ម៉ោង', '_____________ USD/hour') : val('_________________')} ផ្អែកលើការបង្រៀនជាក់ស្តែង។
                    <p className="font-sans italic text-slate-600 mt-0.5">
                      <span className="font-semibold not-italic">Monthly Basic Salary:</span> {data.paymentType === 'monthly' ? val(data.monthlySalaryAmount + ' USD', '__________ USD') : '_______ USD'} or hourly pay based on the teaching schedule.
                    </p>
                  </div>

                  <div>
                    <span className="font-semibold">៥.២</span> និយោជិតទទួលបានអាហារូបករណ៍សម្រាប់ក្រុមគ្រួសារ ដោយផ្អែកលើគោលការណ៍ណែនាំស្តីពីអាហារូបករណ៍សិការបស់ អិន ធី ស៊ី គ្រុប។
                    <p className="font-sans italic text-slate-600 mt-0.5">
                      The Employee will receive the family scholarship based on the educational scholarship guidelines of NTC Group.
                    </p>
                  </div>

                  <div>
                    <span className="font-semibold">៥.៣</span> និយោជិតនឹងទទួលបានអត្ថប្រយោជន៍ផ្សេងទៀត យោងទៅតាមគោលនយោបាយរបស់ អិន ធី ស៊ី គ្រុប។
                    <p className="font-sans italic text-slate-600 mt-0.5">
                      The Employee will receive other benefits according to the NTC Group’s policy.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <p className="font-bold mt-2">
                  ៦. និយោជិតនឹងទទួលបានប្រាក់ឧបត្ថម្ភសម្រាប់ការបំពេញកាតព្វកិច្ចរបស់ខ្លួនដូចជា៖
                </p>
                <p className="font-sans italic text-slate-600 pl-4">
                  The Employee shall receive allowances for performing his/her duties:
                </p>
                
                <div className="pl-4 mt-1">
                  <span className="font-semibold">៦.១</span> ប្រាក់ឧបត្ថម្ភថ្លៃអាហារ ការធ្វើដំណើរ និងការស្នាក់នៅ នឹងត្រូវផ្តល់ជូនសម្រាប់បេសកកម្មណាមួយដែលបានធ្វើឡើងស្របតាមគោលនយោបាយ អិន ធី ស៊ី គ្រុប។
                  <p className="font-sans italic text-slate-600 mt-0.5">
                    Meal, transportation, and accommodation allowance will be provided for any mission taken refers to NTC Group’s policy.
                  </p>
                </div>
              </div>

              <div>
                <p className="font-bold mt-2">
                  ៧. និយោជិតនឹងទទួលខុសត្រូវចំពោះពន្ធលើប្រាក់រៀវត្ស ប្រាក់ឧបត្ថម្ភ និងពន្ធផ្សេងៗទៀតដែលទាក់ទង។ អិន ធី ស៊ី គ្រុប នឹងកាត់ទុក និងបង់ពន្ធទាំងនោះជូនរដ្ឋាភិបាលជាតំណាងឱ្យបុគ្គលិកដោយផ្អែកលើច្បាប់សារពើពន្ធកម្ពុជា។
                </p>
                <p className="font-sans italic text-slate-600 pl-4">
                  The Employee is responsible for the taxes on salary, allowances, and any other applicable taxes. NTC Group will withhold and pay these taxes to the government on behalf of the Employees in accordance with Cambodian taxation law.
                </p>
              </div>

              <div>
                <p className="font-bold mt-2">
                  ៨. ការបញ្ចប់កិច្ចសន្យាការងារ៖ <span className="font-normal font-sans">(១) និយោជកអាចបញ្ចប់កិច្ចសន្យានេះបាននៅពេលណាក៏បាន ប្រសិនបើនិយោជិតរំលោភលើគោលនយោបាយរបស់ អិន ធី ស៊ី គ្រុប រួមមានមិនកំណត់ចំពោះការប្រព្រឹត្តិបទល្មើសព្រហ្មទណ្ឌ អំពើពុករលួយ គេចវេស ឬគ្មានប្រសិទ្ធភាពការងារ។</span>
                </p>
              </div>

            </div>

            {/* Footer */}
            <div className="absolute bottom-6 left-15 right-15 flex justify-between text-[10px] text-slate-450 border-t border-slate-100 pt-2">
              <span>Employment Contract - Teach Staff</span>
              <span>Page 3 of 4</span>
            </div>
          </div>


          {/* PAGE 4 */}
          <div className="document-page text-justify" id="contract-page-4">
            <div className="space-y-4 text-xs leading-relaxed text-slate-800">
              
              <div>
                <p className="font-sans pl-4">
                  ការកេងប្រវ័ញ្ច អំពើឆបោក ឬបំពេញការងារមិនបានលទ្ធផលស្របតាមការរំពឹងទុករបស់សាលា។ (២) ភាគីទាំងពីរអាចបញ្ចប់កិច្ចសន្យានេះបានតាមរយះការផ្តល់លិខិតជូនដំណឹងជាមុន ស្របទៅតាមលក្ខខណ្ឌនៃកិច្ចសន្យាការងារ និងគោលនយោបាយរបស់ អិន ធី ស៊ី គ្រុប។
                </p>
                <p className="font-sans italic text-slate-600 pl-4 mt-1">
                  <span className="font-bold not-italic">Termination of Employment Contract:</span> (1) The Employer may terminate this contract at any time if the Employee violates NTC Group’s policies, including but not limited to serious criminal activities, corruption, exploitation, fraud, or failure to meet performance expectations. (2) Either party may terminate this contract by providing prior notice, in accordance with the terms of the employment contract and the policies of NTC Group.
                </p>
              </div>

              <div>
                <p className="font-bold mt-2">
                  ៩. ការប្រតិបត្តិតាមគោលនយោបាយ និងគោលការណ៍ណែនាំរបស់ អិន ធី ស៊ី គ្រុប៖ <span className="font-normal font-sans">និយោជិតត្រូវបានតម្រូវឱ្យគោរព និងអនុវត្តន៍តាមយ៉ាងតឹងរឹងនូវរាល់ព័ត៌មានដែលបានចែងក្នុងគោលនយោបាយ និងលិខិតណែនាំទាំងអស់របស់ អិន ធី ស៊ី គ្រុប រួមមានដូចជា៖ គោលនយោបាយធនធានមនុស្ស គោលនយោបាយហិរញ្ញវត្ថុ គោលនយោបាយរដ្ឋបាល គោលនយោបាយលទ្ធកម្ម គោលនយោបាយសិក្សាធិការ និងគោលនយោបាយដទៃទៀត។</span>
                </p>
                <p className="font-sans italic text-slate-600 pl-4 mt-1">
                  <span className="font-bold not-italic">Compliance with NTC Group's Policies and Guidelines:</span> The Employee is required to adhere to and perform in accordance with all applicable NTC Group policies and guidelines. This includes but is not limited to, the HR policy, Finance policy, Admin policy, Procurement policy, Academic policy, and any other policies issued by NTC Group.
                </p>
              </div>

              <div className="pt-4 border-t border-slate-150 text-center">
                <p className="font-bold text-slate-900 font-sans">
                  ភាគីទាំងពីរបានអាន បានយល់ និងបានព្រមព្រៀងអនុវត្តកិច្ចសន្យានេះចាប់ពីថ្ងៃចុះហត្ថលេខានេះតទៅ។
                </p>
                <p className="font-sans italic text-slate-600 font-bold mt-0.5">
                  This contract has been read, understood, and agreed upon by both parties.
                </p>
              </div>

              {/* Final Signatures layout mimicking standard legal style */}
              <div className="grid grid-cols-3 gap-4 pt-8 text-center" style={{ minHeight: '150px' }}>
                <div className="flex flex-col justify-between">
                  <div>
                    <p className="font-bold leading-normal">ហត្ថលេខា និងឈ្មោះនិយោជក</p>
                    <p className="font-sans text-[10px] text-slate-600 italic">Employer's Signature & Name</p>
                  </div>
                  <div className="pt-12">
                    <p className="font-bold line-clamp-1 border-b border-slate-250 pb-1 inline-block min-w-[120px]">
                      {data.representativeKh ? data.representativeKh : '.....................................'}
                    </p>
                    <p className="font-sans text-[10px] text-slate-500 mt-1">{data.representativeRoleEn}</p>
                  </div>
                </div>

                <div className="flex flex-col justify-between border-l border-r border-slate-100">
                  <div>
                    <p className="font-bold leading-normal">ហត្ថលេខា និងឈ្មោះសាក្សី</p>
                    <p className="font-sans text-[10px] text-slate-600 italic">Witness's Signature & Name</p>
                  </div>
                  <div className="pt-12">
                    <p className="font-bold border-b border-slate-250 pb-1 inline-block min-w-[120px]">
                      .....................................
                    </p>
                    <p className="font-sans text-[10px] text-slate-500 mt-1">Witness</p>
                  </div>
                </div>

                <div className="flex flex-col justify-between">
                  <div>
                    <p className="font-bold leading-normal">ហត្ថលេខា និងឈ្មោះនិយោជិត</p>
                    <p className="font-sans text-[10px] text-slate-600 italic">Employee's Signature & Name</p>
                  </div>
                  <div className="pt-12">
                    <p className="font-bold line-clamp-1 border-b border-slate-250 pb-1 inline-block min-w-[120px]">
                      {data.employeeKh ? data.employeeKh : '.....................................'}
                    </p>
                    <p className="font-sans text-[10px] text-slate-500 mt-1">Employee / Teacher</p>
                  </div>
                </div>
              </div>

              {/* Signature Dates */}
              <div className="grid grid-cols-3 gap-4 mt-4 text-[10px] text-slate-600">
                <div className="text-center font-semibold">
                  កាលបរិច្ឆេទ(Date)៖ {val(data.signingDateEmployer, '___/____/___')}
                </div>
                <div className="text-center font-semibold">
                  កាលបរិច្ឆេទ(Date)៖ {val(data.signingDateWitness, '___/____/___')}
                </div>
                <div className="text-center font-semibold">
                  កាលបរិច្ឆេទ(Date)៖ {val(data.signingDateEmployee, '___/____/___')}
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="absolute bottom-6 left-15 right-15 flex justify-between text-[10px] text-slate-450 border-t border-slate-100 pt-2">
              <span>Employment Contract - Teach Staff</span>
              <span>Page 4 of 4</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
