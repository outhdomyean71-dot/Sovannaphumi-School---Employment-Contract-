/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ContractData } from '../types';
import { 
  School, 
  User, 
  Briefcase, 
  DollarSign, 
  Calendar, 
  Sparkles, 
  Trash2, 
  MapPin, 
  Languages,
  Clock,
  Upload,
  Image as ImageIcon
} from 'lucide-react';
import { Logo } from './Logo';

interface ContractFormProps {
  data: ContractData;
  onChange: (newData: ContractData) => void;
  onLoadSample: () => void;
  onClear: () => void;
  highlightBlanks: boolean;
  setHighlightBlanks: (val: boolean) => void;
}

export const ContractForm: React.FC<ContractFormProps> = ({
  data,
  onChange,
  onLoadSample,
  onClear,
  highlightBlanks,
  setHighlightBlanks
}) => {
  const [activeTab, setActiveTab] = useState<'school' | 'employee' | 'job' | 'salary' | 'signatures'>('school');

  const handleFieldChange = (key: keyof ContractData, value: string) => {
    onChange({
      ...data,
      [key]: value
    });
  };

  const handleHoursTypeChange = (type: 'fullTime' | 'subjectTeacher' | 'partTime') => {
    onChange({
      ...data,
      workingHoursType: type
    });
  };

  const handlePaymentTypeChange = (type: 'monthly' | 'hourly') => {
    onChange({
      ...data,
      paymentType: type
    });
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('ទំហំរូបភាពលើសពី 2MB! សូមជ្រើសរើសរូបភាពតូចជាងនេះ។\nFile size exceeds 2MB! Please select a smaller image.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result;
        if (typeof result === 'string') {
          onChange({
            ...data,
            customLogoUrl: result
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleResetLogo = () => {
    const newData = { ...data };
    delete newData.customLogoUrl;
    onChange(newData);
  };

  const tabClass = (tabName: typeof activeTab) => {
    const isActive = activeTab === tabName;
    return `flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-all ${
      isActive 
        ? 'border-blue-600 text-blue-600 bg-blue-50/50' 
        : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
    }`;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
      {/* Form Action Controls */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap gap-2 items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-slate-800 flex items-center gap-1">
            <Languages className="w-4 h-4 text-slate-500" />
            បំពេញទិន្នន័យ / Input Form
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onLoadSample}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors shadow-sm cursor-pointer"
            title="បំពេញទិន្នន័យគំរូ"
          >
            <Sparkles className="w-3.5 h-3.5" />
            ទិន្នន័យគំរូ / Load Sample
          </button>
          
          <button
            type="button"
            onClick={onClear}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg transition-colors cursor-pointer"
            title="សម្អាតទិន្នន័យទាំងអស់"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-500" />
            សម្អាត / Clear
          </button>

          <label className="flex items-center gap-2 cursor-pointer bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 transition">
            <input 
              type="checkbox" 
              checked={highlightBlanks} 
              onChange={() => setHighlightBlanks(!highlightBlanks)} 
              className="rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <span>បង្ហាញចន្លោះ / Highight</span>
          </label>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-200 overflow-x-auto no-print">
        <button className={tabClass('school')} onClick={() => setActiveTab('school')}>
          <School className="w-4 h-4" />
          <span>សាលារៀន (School)</span>
        </button>
        <button className={tabClass('employee')} onClick={() => setActiveTab('employee')}>
          <User className="w-4 h-4" />
          <span>និយោជិត (Employee)</span>
        </button>
        <button className={tabClass('job')} onClick={() => setActiveTab('job')}>
          <Briefcase className="w-4 h-4" />
          <span>ការងារ (Duty)</span>
        </button>
        <button className={tabClass('salary')} onClick={() => setActiveTab('salary')}>
          <DollarSign className="w-4 h-4" />
          <span>ប្រាក់បៀវត្ស (Salary)</span>
        </button>
        <button className={tabClass('signatures')} onClick={() => setActiveTab('signatures')}>
          <Calendar className="w-4 h-4" />
          <span>ហត្ថលេខា (Sign Date)</span>
        </button>
      </div>

      {/* Form Fields Content */}
      <div className="p-6 flex-1 overflow-y-auto space-y-6">
        
        {/* TAB 1: CAMPUS & EMPLOYER */}
        {activeTab === 'school' && (
          <div className="space-y-4 animate-fadeIn">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-100">
              <School className="w-5 h-5 text-blue-600" />
              ព័ត៌មានសាលារៀន និងតំណាងភាគីសាលា (School & Rep Profile)
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ឈ្មោះសាខា (ខ្មែរ) / Campus Name (Khmer)
                </label>
                <input
                  type="text"
                  value={data.campusKh}
                  onChange={(e) => handleFieldChange('campusKh', e.target.value)}
                  placeholder="ឧ. សាខាទួលគោក ២"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ឈ្មោះសាខា (English) / Campus Name (English)
                </label>
                <input
                  type="text"
                  value={data.campusEn}
                  onChange={(e) => handleFieldChange('campusEn', e.target.value)}
                  placeholder="e.g. Tuol Kork II"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ឈ្មោះតំណាង (ខ្មែរ) / Legal Rep Name (Khmer)
                </label>
                <input
                  type="text"
                  value={data.representativeKh}
                  onChange={(e) => handleFieldChange('representativeKh', e.target.value)}
                  placeholder="ឧ. លី ហុង"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ឈ្មោះតំណាង (English) / Legal Rep Name (English)
                </label>
                <input
                  type="text"
                  value={data.representativeEn}
                  onChange={(e) => handleFieldChange('representativeEn', e.target.value)}
                  placeholder="e.g. Ly Hong"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  តួនាទីតំណាង (ខ្មែរ) / Representative Role (Khmer)
                </label>
                <input
                  type="text"
                  value={data.representativeRoleKh}
                  onChange={(e) => handleFieldChange('representativeRoleKh', e.target.value)}
                  placeholder="ឧ. នាយិកាសាលា"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  តួនាទីតំណាង (English) / Representative Role (English)
                </label>
                <input
                  type="text"
                  value={data.representativeRoleEn}
                  onChange={(e) => handleFieldChange('representativeRoleEn', e.target.value)}
                  placeholder="e.g. School Principal"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>
            </div>

            {/* Custom Logo Upload Section */}
            <div className="mt-6 p-5 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-xl space-y-4">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-blue-600" />
                <span className="text-sm font-bold text-slate-800">
                  ផ្លាស់ប្តូររូបសញ្ញាសាលា (រូបសញ្ញាផ្ទាល់ខ្លួន) / Custom School Logo
                </span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                អ្នកអាចបញ្ចូលរូបសញ្ញា (Logo) ផ្ទាល់ខ្លួនរបស់អ្នកដើម្បីបង្ហាញនៅលើកិច្ចសន្យាការងារនេះ ជំនួសរូបសញ្ញាលំនាំដើមរបស់សាលា។
                You can upload a custom campus/company logo to replace the default Sovannaphumi School logo on this contract paper.
              </p>
              
              <div className="flex flex-wrap items-center gap-5 bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                {/* Current logo preview */}
                <div className="w-20 h-20 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-center p-2 overflow-hidden shadow-inner relative">
                  {data.customLogoUrl ? (
                    <img 
                      src={data.customLogoUrl} 
                      alt="Custom logo" 
                      className="w-full h-full object-contain"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <Logo size={60} />
                  )}
                </div>

                <div className="flex-1 min-w-[200px] space-y-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <label className="px-4 py-2 bg-blue-600 hover:bg-blue-700 hover:scale-[1.02] active:scale-[0.98] text-white rounded-lg text-xs font-bold shadow-sm transition-all duration-150 cursor-pointer flex items-center gap-1.5">
                      <Upload className="w-3.5 h-3.5" />
                      <span>បញ្ចូលរូបភាព / Upload Image</span>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleLogoUpload}
                        className="hidden" 
                      />
                    </label>

                    {data.customLogoUrl && (
                      <button
                        type="button"
                        onClick={handleResetLogo}
                        className="px-4 py-2 bg-rose-50 hover:bg-rose-100 hover:text-rose-700 text-rose-600 border border-rose-100 rounded-lg text-xs font-bold transition-all duration-150"
                      >
                        ប្រើលំនាំដើម / Reset to Default
                      </button>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Supports high-resolution PNG, JPG, WEBP, or SVG vectors. Max file size: 2MB.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: EMPLOYEE PROFILE */}
        {activeTab === 'employee' && (
          <div className="space-y-4 animate-fadeIn">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-100">
              <User className="w-5 h-5 text-blue-600" />
              ព័ត៌មានបុគ្គលិក / Employee Identity
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ឈ្មោះនិយោជិត (ខ្មែរ) / Employee Name (Khmer)
                </label>
                <input
                  type="text"
                  value={data.employeeKh}
                  onChange={(e) => handleFieldChange('employeeKh', e.target.value)}
                  placeholder="ឧ. អៀន ឧត្តម"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ឈ្មោះនិយោជិត (English) / Employee Name (English)
                </label>
                <input
                  type="text"
                  value={data.employeeEn}
                  onChange={(e) => handleFieldChange('employeeEn', e.target.value)}
                  placeholder="e.g. Yean Outhdom"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  អត្តសញ្ញាណប័ណ្ណ ឬ លិខិតឆ្លងដែនលេខ / ID Card or Passport No.
                </label>
                <input
                  type="text"
                  value={data.employeeId}
                  onChange={(e) => handleFieldChange('employeeId', e.target.value)}
                  placeholder="ឧ. 010345678"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ទូរស័ព្ទដៃលេខ / Phone Number
                </label>
                <input
                  type="text"
                  value={data.employeePhone}
                  onChange={(e) => handleFieldChange('employeePhone', e.target.value)}
                  placeholder="ឧ. 012 345 678"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                />
              </div>
            </div>

            <h4 className="text-sm font-bold text-slate-700 flex items-center gap-2 pt-2 pb-1 border-b border-slate-100 italic">
              <MapPin className="w-4 h-4 text-emerald-500" />
              អាសយដ្ឋានបច្ចុប្បន្ន (Current Address)
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ផ្ទះលេខ / House No
                </label>
                <input
                  type="text"
                  value={data.houseNo}
                  onChange={(e) => handleFieldChange('houseNo', e.target.value)}
                  placeholder="ឧ. ១២អា (12A)"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>
              
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ផ្លូវលេខ / Street
                </label>
                <input
                  type="text"
                  value={data.street}
                  onChange={(e) => handleFieldChange('street', e.target.value)}
                  placeholder="ឧ. ៣១៥"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ភូមិ / Village
                </label>
                <input
                  type="text"
                  value={data.village}
                  onChange={(e) => handleFieldChange('village', e.target.value)}
                  placeholder="ឧ. ភូមិ១"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ឃុំ-សង្កាត់ (ខ្មែរ) / Sangkat (Kh)
                </label>
                <input
                  type="text"
                  value={data.sangkatKh}
                  onChange={(e) => handleFieldChange('sangkatKh', e.target.value)}
                  placeholder="ឧ. បឹងកក់១"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Sangkat (En)
                </label>
                <input
                  type="text"
                  value={data.sangkatEn}
                  onChange={(e) => handleFieldChange('sangkatEn', e.target.value)}
                  placeholder="e.g. Boeung Kak I"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ស្រុក-ខណ្ឌ (ខ្មែរ) / District (Kh)
                </label>
                <input
                  type="text"
                  value={data.khanKh}
                  onChange={(e) => handleFieldChange('khanKh', e.target.value)}
                  placeholder="ឧ. ទួលគោក"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  District / Khan (En)
                </label>
                <input
                  type="text"
                  value={data.khanEn}
                  onChange={(e) => handleFieldChange('khanEn', e.target.value)}
                  placeholder="e.g. Tuol Kork"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ខេត្ត-ក្រុង (ខ្មែរ) / City (Kh)
                </label>
                <input
                  type="text"
                  value={data.cityKh}
                  onChange={(e) => handleFieldChange('cityKh', e.target.value)}
                  placeholder="ឧ. ភ្នំពេញ"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  City / Province (En)
                </label>
                <input
                  type="text"
                  value={data.cityEn}
                  onChange={(e) => handleFieldChange('cityEn', e.target.value)}
                  placeholder="e.g. Phnom Penh"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ប្រទេស (ខ្មែរ) / Country (Kh)
                </label>
                <input
                  type="text"
                  value={data.countryKh}
                  onChange={(e) => handleFieldChange('countryKh', e.target.value)}
                  placeholder="ឧ. កម្ពុជា"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Country Name (En)
                </label>
                <input
                  type="text"
                  value={data.countryEn}
                  onChange={(e) => handleFieldChange('countryEn', e.target.value)}
                  placeholder="e.g. Cambodia"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: DUTIES & WORKING HOURS */}
        {activeTab === 'job' && (
          <div className="space-y-4 animate-fadeIn">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-100">
              <Briefcase className="w-5 h-5 text-blue-600" />
              តួនាទី និងរយៈពេលកិច្ចសន្យា (Job Duty & Contract Period)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  បំរើសេវាកម្មជាតួនាទី (ខ្មែរ) / Position Role (Khmer)
                </label>
                <input
                  type="text"
                  value={data.positionKh}
                  onChange={(e) => handleFieldChange('positionKh', e.target.value)}
                  placeholder="ឧ. គ្រូបង្រៀនភាសាអង់គ្លេស"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Position Role (English)
                </label>
                <input
                  type="text"
                  value={data.positionEn}
                  onChange={(e) => handleFieldChange('positionEn', e.target.value)}
                  placeholder="e.g. English Student Advisor / Teacher"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ធ្វើរបាយការណ៍ផ្ទាល់ជូន (ខ្មែរ) / Reports Directly To (Khmer)
                </label>
                <input
                  type="text"
                  value={data.reportsToKh}
                  onChange={(e) => handleFieldChange('reportsToKh', e.target.value)}
                  placeholder="ឧ. នាយិកាសាលា"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Reports Directly To (English)
                </label>
                <input
                  type="text"
                  value={data.reportsToEn}
                  onChange={(e) => handleFieldChange('reportsToEn', e.target.value)}
                  placeholder="e.g. School Principal"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
              </div>
            </div>

            <h4 className="text-sm font-bold text-slate-700 flex items-center gap-2 pt-2 pb-1 border-b border-slate-100 italic">
              <Calendar className="w-4 h-4 text-emerald-500" />
              រយៈពេលកិច្ចសន្យាភាក្សា (Contract Duration)
            </h4>

            <div className="p-4 bg-blue-50/50 rounded-xl space-y-4 border border-blue-100">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div>
                  <label className="block text-2xs font-bold text-slate-600 mb-0.5">ចាប់ផ្តើម ថ្ងៃទី / Start Day</label>
                  <input type="text" value={data.startDateDay} onChange={(e) => handleFieldChange('startDateDay', e.target.value)} placeholder="01" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
                <div>
                  <label className="block text-2xs font-bold text-slate-600 mb-0.5">ចាប់ផ្តើម ខែ (ខ្មែរ) / Start Month</label>
                  <input type="text" value={data.startDateMonthKh} onChange={(e) => handleFieldChange('startDateMonthKh', e.target.value)} placeholder="កក្កដា" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
                <div>
                  <label className="block text-2xs font-bold text-slate-600 mb-0.5">Start Month (En)</label>
                  <input type="text" value={data.startDateMonthEn} onChange={(e) => handleFieldChange('startDateMonthEn', e.target.value)} placeholder="July" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
                <div>
                  <label className="block text-2xs font-bold text-slate-600 mb-0.5">ចាប់ផ្តើម ឆ្នាំ / Start Year</label>
                  <input type="text" value={data.startDateYear} onChange={(e) => handleFieldChange('startDateYear', e.target.value)} placeholder="2026" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div>
                  <label className="block text-2xs font-bold text-slate-600 mb-0.5">បញ្ចប់ ថ្ងៃទី / End Day</label>
                  <input type="text" value={data.endDateDay} onChange={(e) => handleFieldChange('endDateDay', e.target.value)} placeholder="30" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
                <div>
                  <label className="block text-2xs font-bold text-slate-600 mb-0.5">បញ្ចប់ ខែ (ខ្មែរ) / End Month</label>
                  <input type="text" value={data.endDateMonthKh} onChange={(e) => handleFieldChange('endDateMonthKh', e.target.value)} placeholder="មិថុនា" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
                <div>
                  <label className="block text-2xs font-bold text-slate-600 mb-0.5">End Month (En)</label>
                  <input type="text" value={data.endDateMonthEn} onChange={(e) => handleFieldChange('endDateMonthEn', e.target.value)} placeholder="June" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
                <div>
                  <label className="block text-2xs font-bold text-slate-600 mb-0.5">បញ្ចប់ ឆ្នាំ / End Year</label>
                  <input type="text" value={data.endDateYear} onChange={(e) => handleFieldChange('endDateYear', e.target.value)} placeholder="2027" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-blue-100">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-0.5">កិច្ចសន្យា ចាប់ផ្តើម (English Full Text)</label>
                  <input type="text" value={data.startDateEn} onChange={(e) => handleFieldChange('startDateEn', e.target.value)} placeholder="July 01, 2026" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-0.5">កិច្ចសន្យា បញ្ចប់ (English Full Text)</label>
                  <input type="text" value={data.endDateEn} onChange={(e) => handleFieldChange('endDateEn', e.target.value)} placeholder="June 30, 2027" className="w-full text-xs p-2 bg-white border border-slate-200 rounded" />
                </div>
              </div>
            </div>

            <h4 className="text-sm font-bold text-slate-700 flex items-center gap-2 pt-2 pb-1 border-b border-slate-100 italic">
              <Clock className="w-4 h-4 text-emerald-500" />
              ប្រភេទទម្រង់ម៉ោងការងារ (Working Hours Type)
            </h4>

            <div className="flex flex-col gap-3">
              <div className="flex flex-wrap gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer font-medium text-xs text-slate-700">
                  <input
                    type="radio"
                    name="workingHoursType"
                    checked={data.workingHoursType === 'fullTime'}
                    onChange={() => handleHoursTypeChange('fullTime')}
                    className="text-blue-600 cursor-pointer"
                  />
                  ៣.១ ពេញម៉ោង (Full-Time)
                </label>
                <label className="flex items-center gap-2 cursor-pointer font-medium text-xs text-slate-700">
                  <input
                    type="radio"
                    name="workingHoursType"
                    checked={data.workingHoursType === 'subjectTeacher'}
                    onChange={() => handleHoursTypeChange('subjectTeacher')}
                    className="text-blue-600 cursor-pointer"
                  />
                  ៣.២ តាមមុខវិជ្ជា (Subject Teacher)
                </label>
                <label className="flex items-center gap-2 cursor-pointer font-medium text-xs text-slate-700">
                  <input
                    type="radio"
                    name="workingHoursType"
                    checked={data.workingHoursType === 'partTime'}
                    onChange={() => handleHoursTypeChange('partTime')}
                    className="text-blue-600 cursor-pointer"
                  />
                  ៣.៣ ក្រៅម៉ោង (Part-Time / hourly)
                </label>
              </div>

              {data.workingHoursType === 'fullTime' && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-150 animate-slideDown">
                  <div>
                    <label className="block text-2xs font-bold text-slate-600">ព្រឹកចាប់ពី / Morning From</label>
                    <input type="text" value={data.ftMorningStart} onChange={(e) => handleFieldChange('ftMorningStart', e.target.value)} placeholder="០៧:៣០" className="w-full text-xs p-2 bg-white border border-slate-200 rounded mt-1" />
                  </div>
                  <div>
                    <label className="block text-2xs font-bold text-slate-600">ដល់ម៉ោង / Morning To</label>
                    <input type="text" value={data.ftMorningEnd} onChange={(e) => handleFieldChange('ftMorningEnd', e.target.value)} placeholder="១១:៣០" className="w-full text-xs p-2 bg-white border border-slate-200 rounded mt-1" />
                  </div>
                  <div>
                    <label className="block text-2xs font-bold text-slate-600">រសៀលចាប់ពី / Afternoon From</label>
                    <input type="text" value={data.ftAfternoonStart} onChange={(e) => handleFieldChange('ftAfternoonStart', e.target.value)} placeholder="១៣:៣០" className="w-full text-xs p-2 bg-white border border-slate-200 rounded mt-1" />
                  </div>
                  <div>
                    <label className="block text-2xs font-bold text-slate-600">ដល់ម៉ោង / Afternoon To</label>
                    <input type="text" value={data.ftAfternoonEnd} onChange={(e) => handleFieldChange('ftAfternoonEnd', e.target.value)} placeholder="១៧:០០" className="w-full text-xs p-2 bg-white border border-slate-200 rounded mt-1" />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ថ្ងៃធ្វើការ (ខ្មែរ) / Working Days (Khmer)
                  </label>
                  <input
                    type="text"
                    value={data.workDaysKh}
                    onChange={(e) => handleFieldChange('workDaysKh', e.target.value)}
                    placeholder="ឧ. ច័ន្ទ ដល់ សុក្រ"
                    className="w-full text-sm px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Working Days (English)
                  </label>
                  <input
                    type="text"
                    value={data.workDaysEn}
                    onChange={(e) => handleFieldChange('workDaysEn', e.target.value)}
                    placeholder="e.g. Monday to Friday"
                    className="w-full text-sm px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SALARY & BENEFITS */}
        {activeTab === 'salary' && (
          <div className="space-y-4 animate-fadeIn">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-100">
              <DollarSign className="w-5 h-5 text-blue-600" />
              ប្រាក់បៀវត្ស និង អត្ថប្រយោជន៍ (Salary & Benefits Guidelines)
            </h3>

            <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl space-y-4">
              <div>
                <label className="block text-xs font-bold text-emerald-850 mb-2">
                  របៀបគណនាប្រាក់បៀវត្ស (Salary Calculation Type)
                </label>
                
                <div className="flex gap-4 mb-3">
                  <label className="flex items-center gap-2 cursor-pointer font-medium text-xs text-emerald-900">
                    <input
                      type="radio"
                      name="paymentType"
                      checked={data.paymentType === 'monthly'}
                      onChange={() => handlePaymentTypeChange('monthly')}
                      className="text-emerald-600 cursor-pointer focus:ring-emerald-500"
                    />
                    ប្រាក់បៀវត្សគោលប្រចាំខែ (Monthly Basic Salary)
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer font-medium text-xs text-emerald-950">
                    <input
                      type="radio"
                      name="paymentType"
                      checked={data.paymentType === 'hourly'}
                      onChange={() => handlePaymentTypeChange('hourly')}
                      className="text-emerald-600 cursor-pointer focus:ring-emerald-500"
                    />
                    គណនាតាមម៉ោងបង្រៀន (Hourly Rate Payment)
                  </label>
                </div>
              </div>

              {data.paymentType === 'monthly' ? (
                <div className="animate-slideDown">
                  <label className="block text-xs font-bold text-emerald-800 mb-1">
                    ប្រាក់បៀវត្សគោលប្រចាំខែ (USD) / Monthly Basic Salary (USD Amount)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm font-semibold">$</span>
                    <input
                      type="text"
                      value={data.monthlySalaryAmount}
                      onChange={(e) => handleFieldChange('monthlySalaryAmount', e.target.value)}
                      placeholder="ឧ. 850"
                      className="w-full text-sm pl-8 pr-3.5 py-2.5 bg-white border border-slate-250 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition"
                    />
                  </div>
                </div>
              ) : (
                <div className="animate-slideDown">
                  <label className="block text-xs font-bold text-emerald-850 mb-1">
                    អត្រាតាមម៉ោង (USD/Hour) / Hourly Basic Rate (USD Amount)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm font-semibold">$</span>
                    <input
                      type="text"
                      value={data.hourlyRateAmount}
                      onChange={(e) => handleFieldChange('hourlyRateAmount', e.target.value)}
                      placeholder="ឧ. 12"
                      className="w-full text-sm pl-8 pr-3.5 py-2.5 bg-white border border-emerald-250 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 border border-slate-150 rounded-xl">
              <span className="text-xs font-semibold text-slate-500 uppercase block mb-2">គោលការណ៍ផ្សេងៗ (Default Policies Included):</span>
              <ul className="text-xs text-slate-600 space-y-2 list-disc list-inside">
                <li>៥.២ ទទួលបានអាហារូបករណ៍សម្រាប់ក្រុមគ្រួសារ (សិក្សានៅ អាយ ស៊ី ធី គ្រុប NTC Group)</li>
                <li>៥.៣ អត្ថប្រយោជន៍ផ្សេងៗយោងទៅតាមគោលនយោបាយរបស់ក្រុមហ៊ុន</li>
                <li>៦.១ ទទួលបានការឧបត្ថម្ភការធ្វើដំណើរ ម្ហូបអាហារសម្រាប់ការចាត់តាំងបេសកកម្មការងារ</li>
                <li>៧ ការកាត់ពន្ធលើប្រាក់បៀវត្ស ជូនរដ្ឋាភិបាលស្របតាមច្បាប់សារពើពន្ធនៃព្រះរាជាណាចក្រកម្ពុជា</li>
              </ul>
            </div>
          </div>
        )}

        {/* TAB 5: SIGNATURES & DATES */}
        {activeTab === 'signatures' && (
          <div className="space-y-4 animate-fadeIn">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-100">
              <Calendar className="w-5 h-5 text-blue-600" />
              កាលបរិច្ឆេទចុះហត្ថលេខា (Signing Dates for Parties)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  កាលបរិច្ឆេទនិយោជក / Employer Date
                </label>
                <input
                  type="text"
                  value={data.signingDateEmployer}
                  onChange={(e) => handleFieldChange('signingDateEmployer', e.target.value)}
                  placeholder="ឧ. 13/06/2026"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
                <span className="text-2xs text-slate-400 mt-0.5 block">Format: DD/MM/YYYY</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  កាលបរិច្ឆេទសាក្សី / Witness Date
                </label>
                <input
                  type="text"
                  value={data.signingDateWitness}
                  onChange={(e) => handleFieldChange('signingDateWitness', e.target.value)}
                  placeholder="ឧ. 13/06/2026"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
                <span className="text-2xs text-slate-400 mt-0.5 block">Format: DD/MM/YYYY</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  កាលបរិច្ឆេទនិយោជិត / Employee Date
                </label>
                <input
                  type="text"
                  value={data.signingDateEmployee}
                  onChange={(e) => handleFieldChange('signingDateEmployee', e.target.value)}
                  placeholder="ឧ. 13/06/2026"
                  className="w-full text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white"
                />
                <span className="text-2xs text-slate-400 mt-0.5 block">Format: DD/MM/YYYY</span>
              </div>
            </div>

            <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3">
              <span className="text-amber-500 font-bold text-lg leading-none pt-0.5">⚠️</span>
              <div className="space-y-1">
                <h5 className="text-xs font-bold text-amber-800">ការណែនាំអំពីការបោះពុម្ព (Print Instruction)</h5>
                <p className="text-2xs text-amber-700 leading-relaxed">
                  បន្ទាប់ពីបញ្ជូលទិន្នន័យរួចរាល់ សូមចុចប៊ូតុង <strong>បោះពុម្ព (Print Contract)</strong> នៅផ្នែកខាងលើនៃ Preview។ កម្មវិធីនឹងរៀបចំទម្រង់ A4 ចំនួន ៤ ទំព័រស្អាតដោយស្វ័យប្រវត្តិ ត្រៀមសម្រាប់ការបោះពុម្ពពិតប្រាកដ ឬរក្សាទុកជា PDF។
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick guide and signature status bar */}
      <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-500">
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
          រួចរាល់សម្រាប់ដំណើរការបោះពុម្ព
        </span>
        <span>Sovannaphumi Forms Generator v1.2</span>
      </div>
    </div>
  );
};
