/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ContractData {
  // Employer / School details
  campusKh: string;
  campusEn: string;
  representativeKh: string;
  representativeEn: string;
  representativeRoleKh: string;
  representativeRoleEn: string;

  // Employee details
  employeeKh: string;
  employeeEn: string;
  employeeId: string;
  employeePhone: string;
  
  // Address details
  houseNo: string;
  street: string;
  village: string;
  sangkatKh: string;
  sangkatEn: string;
  khanKh: string;
  khanEn: string;
  cityKh: string;
  cityEn: string;
  countryKh: string;
  countryEn: string;

  // Job details
  positionKh: string;
  positionEn: string;
  reportsToKh: string;
  reportsToEn: string;

  // Dates
  startDateDay: string;
  startDateMonthKh: string;
  startDateMonthEn: string;
  startDateYear: string;
  endDateDay: string;
  endDateMonthKh: string;
  endDateMonthEn: string;
  endDateYear: string;
  
  // Full raw formatted dates for English version
  startDateEn: string;
  endDateEn: string;

  // Working Hours details
  workingHoursType: 'fullTime' | 'subjectTeacher' | 'partTime';
  ftMorningStart: string;
  ftMorningEnd: string;
  ftAfternoonStart: string;
  ftAfternoonEnd: string;
  workDaysKh: string;
  workDaysEn: string;

  // Salary
  paymentType: 'monthly' | 'hourly';
  monthlySalaryAmount: string;
  hourlyRateAmount: string;

  // Sign dates
  signingDateEmployer: string;
  signingDateWitness: string;
  signingDateEmployee: string;

  // Custom Logo Upload
  customLogoUrl?: string;
}
