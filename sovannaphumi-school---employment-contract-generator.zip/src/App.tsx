/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ContractData } from './types';
import { sampleContractData, getBlankContractData } from './data/sampleData';
import { ContractForm } from './components/ContractForm';
import { ContractPreview } from './components/ContractPreview';
import { Logo } from './components/Logo';
import { FileText, Printer, Shield, CheckCircle2 } from 'lucide-react';

const LOCAL_STORAGE_KEY = 'sovannaphumi_contract_data';

export default function App() {
  const [data, setData] = useState<ContractData>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse cached contract data', e);
      }
    }
    return sampleContractData;
  });

  const [highlightBlanks, setHighlightBlanks] = useState(true);
  const [scale, setScale] = useState(0.85);
  const [showStatus, setShowStatus] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  const handleDataChange = (newData: ContractData) => {
    setData(newData);
    triggerNotification('បានរក្សាទុកបណ្តោះអាសន្ន / Auto-saved to memory');
  };

  const handleLoadSample = () => {
    if (window.confirm('តើអ្នកពិតជាចង់ផ្ទុកទិន្នន័យគំរូមែនទេ? (ទិន្នន័យបច្ចុប្បន្ននឹងត្រូវជំនួស)')) {
      setData(sampleContractData);
      triggerNotification('បានផ្ទុកទិន្នន័យគំរូរួចរាល់ / Sample loaded success');
    }
  };

  const handleClear = () => {
    if (window.confirm('តើអ្នកពិតជាចង់សម្អាតទិន្នន័យទាំងអស់មែនទេ?')) {
      setData(getBlankContractData());
      triggerNotification('បានសម្អាតរួចរាល់ / Form cleared');
    }
  };

  const triggerNotification = (msg: string) => {
    setStatusMessage(msg);
    setShowStatus(true);
    setTimeout(() => {
      setShowStatus(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      
      {/* Dynamic Notification Bar */}
      {showStatus && (
        <div className="fixed bottom-6 left-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-lg border border-slate-750 flex items-center gap-2 text-xs font-semibold animate-slideUp">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Main Layout Header (Hidden during print) */}
      <header className="bg-[#002B5C] text-white px-6 py-4 flex items-center justify-between shadow-md border-b border-blue-900 no-print">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/10 rounded-lg">
            <FileText className="w-6 h-6 text-yellow-400" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-bold tracking-wide">
              កម្មវិធីបំពេញកិច្ចសន្យាការងារគ្រូបង្រៀន (សាលារៀន សុវណ្ណភូមិ)
            </h1>
            <p className="text-3xs md:text-2xs opacity-75 font-medium mt-0.5">
              Sovannaphumi School - Employment Contract (Teaching Staff) Form Generator
            </p>
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-2 bg-slate-800/40 border border-white/10 px-3 py-1.5 rounded-lg text-2xs font-medium text-slate-300">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>ទិន្នន័យរក្សាទុកក្នុងកុំព្យូទ័រលោកអ្នក (Offline Sandbox Privacy)</span>
        </div>
      </header>

      {/* Main Workspace Frame */}
      <main className="flex-1 flex overflow-hidden relative">
        <div className="w-full flex flex-col lg:flex-row divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
          
          {/* LEFT SIDE: INPUT FORM COLUMN (Hidden during print) */}
          <section className="w-full lg:w-[42%] flex flex-col h-[50vh] lg:h-auto p-4 lg:p-6 bg-slate-50 overflow-hidden no-print">
            <motion.div 
              initial={{ opacity: 0, x: -15 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
              className="h-full flex flex-col"
            >
              <ContractForm 
                data={data}
                onChange={handleDataChange}
                onLoadSample={handleLoadSample}
                onClear={handleClear}
                highlightBlanks={highlightBlanks}
                setHighlightBlanks={setHighlightBlanks}
              />
            </motion.div>
          </section>

          {/* RIGHT SIDE: DOCUMENT VISUAL PREVIEW COLUMN */}
          <section className="flex-1 flex flex-col bg-slate-700/5 overflow-hidden">
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
              className="h-full"
            >
              <ContractPreview 
                data={data}
                highlightBlanks={highlightBlanks}
                scale={scale}
                setScale={setScale}
              />
            </motion.div>
          </section>

        </div>
      </main>

      {/* Hidden layout specifically rendered for standard browser print triggers (A4 size format) */}
      <div className="absolute top-[-9999px] left-[-9999px] print:static print:block w-full">
        {/* Render pages for print explicitly without zoom wrappers or controls */}
        <div className="print-container">
          
          {/* PRINT PAGE 1 */}
          <div className="document-page text-justify relative">
            <div className="flex flex-col items-center mb-6">
              <Logo size={100} customLogoUrl={data.customLogoUrl} className="mb-2" />
              <h1 className="font-moul text-[#0056ac] text-[18px] mt-1 mb-0.5">សាលារៀនសុវណ្ណភូមិ</h1>
              <h2 className="font-sans font-bold text-[#0056ac] text-[16px] mb-4">SOVANNAPHUMI SCHOOL</h2>
              <div className="w-1/2 border-b-2 border-red-650 mb-4"></div>
              <h3 className="font-moul text-[#c41c17] text-[16px] mb-0.5">កិច្ចសន្យាការងារ</h3>
              <h4 className="font-sans font-bold text-[#0056ac] text-[13px] mb-1">EMPLOYMENT CONTRACT</h4>
              <p className="font-moul text-[#0056ac] text-[11px] mb-4">(ផ្នែកគ្រូបង្រៀន Teaching Staff)</p>
            </div>

            <div className="space-y-4 text-xs leading-relaxed text-slate-800">
              <p className="indent-8 font-sans">
                <span className="font-bold">សាលារៀនសុវណ្ណភូមិ</span> នៃ ក្រុមហ៊ុន សហគមន៍ ញូវតុន ធីឡាយ គ្រុប ទីតាំង <span className="border-b border-slate-900 pb-0.5 font-bold">{data.campusKh || '_______________________'}</span> តំណាងពេញច្បាប់ដោយ <span className="border-b border-slate-900 pb-0.5 font-bold">{data.representativeKh || '______________________'}</span> មានតួនាទីជា <span className="border-b border-slate-900 pb-0.5 font-bold">{data.representativeRoleKh || '___________________'}</span> ក្នុងកិច្ចសន្យានេះហៅថាភាគី <span className="font-bold">«និយោជក»</span> ជាមួយ និង <span className="border-b border-slate-900 pb-0.5 font-bold">{data.employeeKh || '______________________________'}</span> កាន់អត្តសញ្ញាណប័ណ្ណលេខ៖ <span className="border-b border-slate-900 pb-0.5 font-bold">{data.employeeId || '____________________'}</span> ទូរស័ព្ទដៃលេខ៖ <span className="border-b border-slate-900 pb-0.5 font-bold">{data.employeePhone || '________________________'}</span> អាសយដ្ឋាន៖ ផ្ទះលេខ <span className="border-b border-slate-900 pb-0.5 font-bold">{data.houseNo || '_____'}</span> ផ្លូវ <span className="border-b border-slate-900 pb-0.5 font-bold">{data.street || '________'}</span> ភូមិ <span className="border-b border-slate-900 pb-0.5 font-bold">{data.village || '_______________'}</span> ឃុំ/សង្កាត់ <span className="border-b border-slate-900 pb-0.5 font-bold">{data.sangkatKh || '__________________'}</span> ស្រុក/ខណ្ឌ <span className="border-b border-slate-900 pb-0.5 font-bold">{data.khanKh || '_________________'}</span> ខេត្ត/ក្រុង <span className="border-b border-slate-900 pb-0.5 font-bold">{data.cityKh || '_____________________'}</span> ប្រទេស <span className="border-b border-slate-900 pb-0.5 font-bold">{data.countryKh || '__________'}</span> ក្នុងកិច្ចសន្យានេះហៅថាភាគី <span className="font-bold">«និយោជិត»</span>។
              </p>

              <p className="font-sans italic text-slate-700">
                <span className="font-bold not-italic text-slate-900">Sovannaphumi School</span> of SAHAKUM NEWTON THILAY GROUP CO., LTD, located at the <span className="border-b border-slate-950 pb-0.5 font-bold">{data.campusEn || '_________________________'}</span> Campus, legally represented by <span className="border-b border-slate-950 pb-0.5 font-bold">{data.representativeEn || '_______________________'}</span> as the <span className="border-b border-slate-950 pb-0.5 font-bold">{data.representativeRoleEn || '__________________'}</span>; hereafter called <span className="font-bold not-italic">“The Employer”</span>
              </p>

              <p className="font-sans italic text-slate-700">
                <span className="font-bold not-italic text-slate-900">And</span> <span className="border-b border-slate-950 pb-0.5 font-bold">{data.employeeEn || '______________________'}</span>, holding ID card/Passport number: <span className="border-b border-slate-950 pb-0.5 font-bold">{data.employeeId || '_______________________'}</span>, Phone#: <span className="border-b border-slate-950 pb-0.5 font-bold">{data.employeePhone || '_____________________'}</span>, Address: <span className="border-b border-slate-950 pb-0.5 font-bold">{data.houseNo}, St. {data.street}, {data.village}, Sangkat {data.sangkatEn}, Khan {data.khanEn}, {data.cityEn}, {data.countryEn}</span>; hereafter called <span className="font-bold not-italic">“The Employee”</span>.
              </p>

              <div className="pt-2 border-t border-slate-200">
                <p className="font-sans font-bold text-slate-955 mb-2">
                  ភាគីទាំងពីរបានប្រកាសយល់ព្រមលើចំណុចដូចខាងក្រោម៖ The parties hereby declare as follows:
                </p>
                <div className="space-y-3 pl-4">
                  <div>
                    <span className="font-bold">ក. សាលារៀនសុវណ្ណភូមិ</span> ភ្ជាប់សេវាកម្មសម្រាប់តួនាទីជា <span className="border-b border-slate-950 pb-0.5 font-bold">{data.positionKh || '______________________________'}</span> ដោយផ្អែកលើលក្ខណៈសម្បត្តិសមត្ថភាព ចំណេះដឹង និងជំនាញ។
                    <p className="font-sans italic text-slate-600 pl-4 mt-0.5">
                      Sovannaphumi School desires to engage with the services of a <span className="border-b border-slate-950 pb-0.5 font-bold">{data.positionEn || '____________________'}</span>, with the right qualifications, education, and expertise for the position.
                    </p>
                  </div>
                  <div>
                    <span className="font-bold">ខ. និយោជិត</span> ត្រូវបានលក្ខណៈសម្បត្តិសមត្ថភាព ចំណេះដឹង និងជំនាញ ដែលត្រូវតាមតួនាទីនេះ ហើយបានយល់ព្រមចូលរួមការងារជាមួយសាលារៀនសុវណ្ណភូមិ។
                    <p className="font-sans italic text-slate-600 pl-4 mt-0.5">
                      The Employee confirms that they possess the qualifications, education, and expertise required for the position and agrees to fulfill the employee role with Sovannaphumi School.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute bottom-6 left-15 right-15 flex justify-between text-[10px] text-slate-500 border-t border-slate-100 pt-2">
              <span>Employment Contract - Teach Staff</span>
              <span>Page 1 of 4</span>
            </div>
          </div>

          <div className="page-break flex print:block"></div>

          {/* PRINT PAGE 2 */}
          <div className="document-page text-justify relative">
            <div className="space-y-4 text-xs leading-relaxed text-slate-800">
              <div>
                <p className="font-bold">១. កិច្ចសន្យានេះ ជាប្រភេទកិច្ចសន្យាការងារដែលមានកំណត់ថិរវេលា។</p>
                <p className="font-sans italic text-slate-600 pl-5 mb-2">This Employment contract is Fixed Duration Contract (FDC).</p>
              </div>

              <div>
                <p className="font-bold">
                  ២. និយោជិតត្រូវបានផ្តល់ការងារដោយសាលារៀនសុវណ្ណភូមិ មានប្រសិទ្ធភាពចាប់ពីថ្ងៃទី <span className="font-bold border-b border-slate-900 px-1">{data.startDateDay || '____'}</span> ខែ <span className="font-bold border-b border-slate-900 px-1">{data.startDateMonthKh || '______'}</span> ឆ្នាំ <span className="font-bold border-b border-slate-900 px-1">{data.startDateYear || '____'}</span> ដល់ថ្ងៃទី <span className="font-bold border-b border-slate-900 px-1">{data.endDateDay || '____'}</span> ខែ <span className="font-bold border-b border-slate-900 px-1">{data.endDateMonthKh || '______'}</span> ឆ្នាំ <span className="font-bold border-b border-slate-900 px-1">{data.endDateYear || '____'}</span> និងត្រូវធ្វើរបាយការណ៍ផ្ទាល់ជូន <span className="font-bold border-b border-slate-900 px-1">{data.reportsToKh || '__________________'}</span>។
                </p>
                <p className="font-sans italic text-slate-600 pl-5 mb-2">
                  The Employee is employed by Sovannaphumi School, in the period from <span className="font-bold border-b border-slate-900 px-1">{data.startDateEn || '_______________'}</span> to <span className="font-bold border-b border-slate-900 px-1">{data.endDateEn || '_______________'}</span>, and reports directly to the <span className="font-bold border-b border-slate-900 px-1">{data.reportsToEn || '____________________'}</span>.
                </p>
              </div>

              <div>
                <p className="font-bold">៣. ម៉ោងពេលបំពេញការងាររបស់និយោជិត Employee Working Hours៖</p>
                <div className="space-y-2 pl-4 mt-2">
                  <div className="flex items-start gap-2">
                    <input type="checkbox" checked={data.workingHoursType === 'fullTime'} readOnly />
                    <div>
                      <span className="font-semibold">៣.១ ពេញម៉ោង៖</span> ព្រឹកចាប់ពីម៉ោង <span className="border-b border-slate-900 font-bold">{data.ftMorningStart || '០៧:៣០'}</span> ដល់ម៉ោង <span className="border-b border-slate-900 font-bold">{data.ftMorningEnd || '១១:៣០'}</span> និងរសៀល ពីម៉ោង <span className="border-b border-slate-900 font-bold">{data.ftAfternoonStart || '១៣:៣០'}</span> ដល់ម៉ោង <span className="border-b border-slate-900 font-bold">{data.ftAfternoonEnd || '១៧:០០'}</span> ហើយធ្វើការពីថ្ងៃ <span className="border-b border-slate-900 font-bold">{data.workDaysKh || 'ច័ន្ទ ដល់ សុក្រ'}</span>។
                      <p className="font-sans italic text-slate-600 mt-0.5">
                        Full-Time: The working hours are from {data.ftMorningStart || '07:30'} to {data.ftMorningEnd || '11:30'} and {data.ftAfternoonStart || '13:30'} to {data.ftAfternoonEnd || '17:00'}, with work scheduled from {data.workDaysEn || 'Monday to Friday'}.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" checked={data.workingHoursType === 'subjectTeacher'} readOnly />
                    <p className="font-semibold">៣.២ តាមមុខវិជ្ជា៖ ផ្អែកលើកាលវិភាគបង្រៀនប្រចាំខែ / Based on monthly schedule.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" checked={data.workingHoursType === 'partTime'} readOnly />
                    <p className="font-semibold">៣.៣ ក្រៅម៉ោង៖ ផ្អែកលើកាលវិភាគបង្រៀនប្រចាំខែ / Based on monthly schedule.</p>
                  </div>
                </div>
              </div>

              <div>
                <p className="font-bold">៤. ភារកិច្ច និងការទទួលខុសត្រូវ៖</p>
                <p className="font-normal pl-2 mt-1">
                  និយោជិតទទួលខុសត្រូវក្នុងការពង្រីក និងការផ្តល់នូវបរិយាកាសអប់រំល្អ ដែលអាចធ្វើឱ្យសិស្សានុសិស្សមានឱកាសបំពេញនូវភាពរីកចម្រើនផ្នែកប្រាជ្ញា ស្មារតី រាងកាយ អារម្មណ៍ និងផ្លូវចិត្ត។ និយោជិតក៏មានភារកិច្ចក្នុងការរៀបចំ និងអនុវត្តនូវវិធីសាស្ត្របង្រៀន ដែលអាចធ្វើឱ្យសិស្សសម្រេចបាននូវភាពជោគជ័យក្នុងការសិក្សា ស្របទៅតាមកម្មវិធីសិក្សារបស់សាលារៀនសុវណ្ណភូមិ។
                </p>
                <p className="font-sans italic text-slate-600 pl-2 mt-1">
                  The Duties and Responsibilities: Employees are responsible for fostering a positive educational environment that supports students' intellectual, emotional, physical, and psychological growth. They are also tasked with designing and implementing effective teaching methods that help students achieve academic success in alignment with the curriculum of Sovannaphumi School.
                </p>
              </div>
            </div>
            <div className="absolute bottom-6 left-15 right-15 flex justify-between text-[10px] text-slate-500 border-t border-slate-100 pt-2">
              <span>Employment Contract - Teach Staff</span>
              <span>Page 2 of 4</span>
            </div>
          </div>

          <div className="page-break flex print:block"></div>

          {/* PRINT PAGE 3 */}
          <div className="document-page text-justify relative">
            <div className="space-y-4 text-xs leading-relaxed text-slate-800">
              <div className="pl-4">
                <p className="font-sans italic text-slate-600">Create a positive environment that actively motivates students throughout the learning process.</p>
                <div className="space-y-3 mt-2 font-sans font-normal text-slate-900">
                  <p><strong>៤.៦</strong> ធ្វើការទំនាក់ទំនងដោយមានភាពជាគំរូ និងមានប្រសិទ្ធភាព ទាំងការនិយាយ និងសរសេរជាមួយសិស្ស មាតាបិតាសិស្ស សហគមន៍ និងអ្នកពាក់ព័ន្ធផ្សេងទៀតឱ្យបានជាប្រចាំ...</p>
                  <p className="italic text-slate-605">Communicate exemplarily and effectively, both orally and in writing, with students, parents, community members, and other stakeholders...</p>
                </div>
              </div>

              <div>
                <p className="font-bold">៥. និយោជិតនឹងទទួលបានប្រាក់រៀវត្ស និងអត្ថប្រយោជន៍ផ្សេងទៀតដូចខាងក្រោម (មុនកាត់ពន្ធ)៖</p>
                <p className="font-sans italic text-slate-600 pl-4">The employee is entitled to the following salary and benefits (before tax):</p>
                <div className="pl-4 mt-2 space-y-2">
                  <p><strong>៥.១</strong> ប្រាក់រៀវត្សគោលប្រចាំខែគឺ: <span className="font-bold border-b border-slate-900 px-1">{data.paymentType === 'monthly' ? data.monthlySalaryAmount + ' USD' : '_________'}</span> ឬ អត្រាម៉ោងគឺ: <span className="font-bold border-b border-slate-900 px-1">{data.paymentType === 'hourly' ? data.hourlyRateAmount + ' USD/Hour' : '_________'}</span>។</p>
                  <p className="font-sans italic text-slate-600">Monthly Basic Salary: {data.paymentType === 'monthly' ? data.monthlySalaryAmount + ' USD' : '________ USD'} or hourly pay based on schedule.</p>
                  <p><strong>៥.២</strong> ទទួលបានអាហារូបករណ៍សម្រាប់ក្រុមគ្រួសារ / Receive family scholarship based on NTC guidelines.</p>
                  <p><strong>៥.៣</strong> ទទួលបានអត្ថប្រយោជន៍ផ្សេងទៀតស្របតាមគោលការណ៍ / Receive benefits according to NTC Group policy.</p>
                </div>
              </div>

              <div>
                <p className="font-bold">៦. ប្រាក់ឧបត្ថម្ភការបំពេញភារកិច្ច / Allowances:</p>
                <p className="pl-4"><strong>៦.១</strong> ប្រាក់ឧបត្ថម្ភការស្នាក់នៅ ម្ហូបអាហារ បំពេញការងារចាត់តាំងខាងក្រៅ / Travel, food, and housing allowance for assigned missions.</p>
              </div>

              <div>
                <p className="font-bold">៧. និយោជិតទទួលខុសត្រូវពន្ធដារ / Tax Responsibility:</p>
                <p className="pl-4">និយោជិតទទួលខុសត្រូវចំពោះការបង់ពន្ធលើបៀវត្ស សាលានឹងកាត់ទុកបង់ជំនួសជូនរដ្ឋតាមច្បាប់សារពើពន្ធកម្ពុជា / Tax is withheld and paid on behalf of employee as per Cambodian tax law.</p>
              </div>
            </div>
            <div className="absolute bottom-6 left-15 right-15 flex justify-between text-[10px] text-slate-500 border-t border-slate-100 pt-2">
              <span>Employment Contract - Teach Staff</span>
              <span>Page 3 of 4</span>
            </div>
          </div>

          <div className="page-break flex print:block"></div>

          {/* PRINT PAGE 4 */}
          <div className="document-page text-justify relative">
            <div className="space-y-4 text-xs leading-relaxed text-slate-800">
              <div>
                <p className="font-bold">៨. ការបញ្ចប់កិច្ចសន្យាការងារ / Contract Termination:</p>
                <p className="pl-4">សាលាអាចបញ្ចប់កិច្ចសន្យានៅពេលណាក៏បាន ប្រសិនបើបុគ្គលិកបំពានគោលការណ៍ ឬមិនមានលទ្ធផលការងារល្អ។ ភាគីទាំងពីរអាចបញ្ចប់ដោយជូនដំណឹងជាមុន។</p>
                <p className="font-sans italic text-slate-600 pl-4">The Employer may terminate if employee violates guidelines, or fails to meet expectations. Either party can terminate with notice.</p>
              </div>

              <div>
                <p className="font-bold">៩. ការអនុវត្តគោលនយោបាយស្ថាប័ន / Compliance:</p>
                <p className="pl-4">ត្រូវអនុវត្តតាមគោលនយោបាយធនធានមនុស្ស ហិរញ្ញវត្ថុ រដ្ឋបាល លទ្ធកម្ម... / Employee must comply with all NTC guidelines (HR, finance, admin, etc).</p>
              </div>

              <div className="pt-4 border-t border-slate-200 text-center">
                <p className="font-bold text-slate-905">ភាគីទាំងពីរបានអាន បានយល់ និងបានព្រមព្រៀងអនុវត្តកិច្ចសន្យានេះចាប់ពីថ្ងៃចុះហត្ថលេខានេះតទៅ។</p>
                <p className="font-sans italic font-bold">This contract has been read, understood, and agreed upon by both parties.</p>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-12 text-center" style={{ minHeight: '140px' }}>
                <div>
                  <p className="font-bold text-xs">ហត្ថលេខា និងឈ្មោះនិយោជក</p>
                  <p className="text-2xs text-slate-500 italic">Employer Sign</p>
                  <div className="pt-12">
                    <p className="border-b border-slate-400 pb-0.5 inline-block min-w-[120px] font-bold">{data.representativeKh || '................'}</p>
                    <p className="text-[9px] text-slate-500 mt-0.5">{data.representativeRoleEn}</p>
                  </div>
                </div>

                <div>
                  <p className="font-bold text-xs">ហត្ថលេខា និងឈ្មោះសាក្សី</p>
                  <p className="text-2xs text-slate-500 italic">Witness Sign</p>
                  <div className="pt-12">
                    <p className="border-b border-slate-400 pb-0.5 inline-block min-w-[120px]">.................</p>
                    <p className="text-[9px] text-slate-500 mt-0.5">Witness</p>
                  </div>
                </div>

                <div>
                  <p className="font-bold text-xs">ហត្ថលេខា និងឈ្មោះនិយោជិត</p>
                  <p className="text-2xs text-slate-500 italic">Employee Sign</p>
                  <div className="pt-12">
                    <p className="border-b border-slate-400 pb-0.5 inline-block min-w-[120px] font-bold">{data.employeeKh || '................'}</p>
                    <p className="text-[9px] text-slate-500 mt-0.5">Employee / Teacher</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-4 text-[10px] text-slate-500">
                <div className="text-center">កាលបរិច្ឆេទ(Date)៖ {data.signingDateEmployer || '___/____/___'}</div>
                <div className="text-center">កាលបរិច្ឆេទ(Date)៖ {data.signingDateWitness || '___/____/___'}</div>
                <div className="text-center">កាលបរិច្ឆេទ(Date)៖ {data.signingDateEmployee || '___/____/___'}</div>
              </div>
            </div>
            <div className="absolute bottom-6 left-15 right-15 flex justify-between text-[10px] text-slate-500 border-t border-slate-100 pt-2">
              <span>Employment Contract - Teach Staff</span>
              <span>Page 4 of 4</span>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
